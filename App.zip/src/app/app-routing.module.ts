import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StudentComponent } from './student/student.component';
//import { StudentListComponent } from './student-list/student-list.component';
import { LecturerComponent } from './lecturer/lecturer.component';
import { CourseComponent } from './course/course.component';

const routes: Routes = [
  {path: 'student' , component:StudentComponent},
 
  {path: 'lecturer' , component:LecturerComponent},
  {path: 'course' , component:CourseComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
