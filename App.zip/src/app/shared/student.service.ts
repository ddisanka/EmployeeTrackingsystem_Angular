import { Injectable } from '@angular/core';
//import { FormBuilder, Validators, FormGroup } from "@angular/forms";
import { HttpClient } from "@angular/common/http";
import { StudentDetail } from './student.model';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
formData: StudentDetail;
readonly BaseURI = "https://localhost:5001/api";
list: StudentDetail[];
  constructor(private http: HttpClient) { }
  
  PostStudent(){
    return this.http.post(this.BaseURI + '/Student',this.formData);
  }
  PutStudent(){
    return this.http.put(this.BaseURI + '/Student/'+this.formData.StudentID, this.formData);
  }
   deleteStudent(id){
     return this.http.delete(this.BaseURI + '/Student')
     .toPromise()
     .then(res=>this.list = res as StudentDetail[]);
   }
   refreshList(){
     this.http.get(this.BaseURI+'/Student')
     .toPromise()
     .then(res=> this.list = res as StudentDetail[]);
   }

}
