export class StudentDetail {
    StudentID : number;
    FirstName : string;
    MiddleName : string;
    LastName : string;
    Mobile : string;
    Telephone : string;
    Email : string;
    Address : string;
    DOB : string;
    NIC : string;
}