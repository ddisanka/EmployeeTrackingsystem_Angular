import { Component, OnInit } from "@angular/core";
import { StudentService } from "src/app/shared/student.service";
import { FormGroup, NgForm } from "@angular/forms";
import { debug } from "util";
@Component({
  selector: "app-student",
  templateUrl: "./student.component.html",
  styleUrls: ["./student.component.css"]
})
export class StudentComponent implements OnInit {
  studentForm : FormGroup;
  constructor(private service: StudentService) {}

  ngOnInit() {
    // this.resetForm();
    this.validationForm();
  }
  
validationForm(form?: NgForm){
  this.studentForm = this.formBuilder.group({
    firstName: ['', Validators.required],
    lastName: ['', Validators.required],
    email:['',[Validators.required, Validators.email]],
    selectedCourse: ['', Validators.required],
    address: ['', Validators.required],
    contactNo: ['', [Validators.required,Validators.minLength(10)]],
    dob: ['', Validators.required],
    doj: ['', Validators.required],
  });
}

  // resetForm(form?: NgForm) {
  //   if (form != null) form.form.reset();
  //   this.service.formData = {
  //     StudentID: 0,
  //     FirstName: "",
  //     MiddleName: "",
  //     LastName: "",
  //     Mobile: "",
  //     Telephone: "",
  //     Email: "",
  //     Address: "",
  //     DOB: "",
  //     NIC: ""
  //   };
  // }
  
  onSubmit(form: NgForm) {
    if (this.service.formData.StudentID == 0) this.insertRecord(form);
    else this.updateRecord(form);
  }

  insertRecord(form: NgForm) {
    this.service.PostStudent().subscribe(
      res => {
        //debugger;
        this.resetForm(form);
      },
      err => {
        //debugger;
        console.log(err);
      }
    );
  }
  updateRecord(form: NgForm) {
    this.service.PutStudent().subscribe(
      res => {
        this.resetForm(form);
      },
      err => {
        console.log(err);
      }
    );
  }
}
