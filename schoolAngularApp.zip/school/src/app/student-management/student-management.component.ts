import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
@Component({
  selector: 'app-student-management',
  templateUrl: './student-management.component.html',
  styleUrls: ['./student-management.component.css']
})
export class StudentManagementComponent implements OnInit {

  student=[
    {
      "studentID":0,
      "firstName": "abc",
      "lastName": "SE",
      "email": "abc@gmail.com",
      "selectedCourse": "SE",
      "address": "12/34,faf,asfas",
      "contactNo": "012345678",
      "dob": "07/16/2019",
      "doj": "07/16/2019",
    },
    {
      "studentID":1,
      "firstName": "abc",
      "lastName": "SE",
      "email": "abc@gmail.com",
      "selectedCourse": "SE",
      "address": "12/34,faf,asfas",
      "contactNo": "012345678",
      "dob": "07/16/2019",
      "doj": "07/16/2019",
    },
    {
      "studentID":2,
      "firstName": "abc",
      "lastName": "SE",
      "email": "abc@gmail.com",
      "selectedCourse": "SE",
      "address": "12/34,faf,asfas",
      "contactNo": "012345678",
      "dob": "07/16/2019",
      "doj": "07/16/2019",
    },
  ]
  studentForm : FormGroup;
  course = [
    {
      "courseID": 0,
      "courseName": "IT",
      "startDate": "07/16/2019",
      "endDate": "07/16/2019"
    },
    {
      "courseID": 1,
      "courseName": "DB",
      "startDate": "07/16/2019",
      "endDate": "07/16/2019"
    },
    {
      "courseID": 2,
      "courseName": "SE",
      "startDate": "07/16/2019",
      "endDate": "07/16/2019"
    }
  ]
  index = 0;
  sub = false;
  li=false;
  ad=false;

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.studentForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email:['',[Validators.required, Validators.email]],
      selectedCourse: ['', Validators.required],
      address: ['', Validators.required],
      contactNo: ['', [Validators.required,Validators.minLength(10)]],
      dob: ['', Validators.required],
      doj: ['', Validators.required],
    });
  }

  get data() { return this.studentForm.controls; }
  


  

  addStudent() {
    this.sub = true
    if (this.studentForm.invalid) {
      return;
  }
    //console.warn(this.studentForm.value);
    console.log(this.studentForm.value);
    var a= this.studentForm.value
    this.student.push(a);
    alert('done');
    // this.student.push({
    //   SID: this.index++,
    //   Fname: this.firstName,
    //   Lname: this.lastName,
    //   Course: this.selectedCourse,
    //   Address: this.address,
    //   Contact: this.contactNo,
    //   DOB: this.dob,
    //   DOJ: this.doj
    // });
    console.log(this.student);
  }

  clear() {
    this.sub = false;
    this.studentForm.reset();
}
  list(){
    this.ad=false;
    this.li=true;

  };
  add(){
    this.li=false;
    this.ad=true;
  };

}
