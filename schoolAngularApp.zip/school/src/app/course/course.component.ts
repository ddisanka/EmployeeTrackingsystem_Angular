import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {
  course = [];
  courseForm: FormGroup;
  index = 0;
  sub = false;
  constructor(private formBuilder: FormBuilder) { }
  ngOnInit() {
    this.courseForm = this.formBuilder.group({
      courseName: ['', Validators.required],
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
    });
  }
  get data() { return this.courseForm.controls; }
  addCourse() {
    this.sub = true
    if (this.courseForm.invalid) {
      return;
    }
    //console.warn(this.studentForm.value);
    console.log(this.courseForm.value);
    var a = this.courseForm.value
    this.course.push(a);
    alert('done');
    // this.student.push({
    //   SID: this.index++,
    //   Fname: this.firstName,
    //   Lname: this.lastName,
    //   Course: this.selectedCourse,
    //   Address: this.address,
    //   Contact: this.contactNo,
    //   DOB: this.dob,
    //   DOJ: this.doj
    // });
    console.log(this.course);
  }
  clear() {
    this.sub = false;
    this.courseForm.reset();
  }
}
