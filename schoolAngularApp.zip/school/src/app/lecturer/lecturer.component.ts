import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-lecturer',
  templateUrl: './lecturer.component.html',
  styleUrls: ['./lecturer.component.css']
})
export class LecturerComponent implements OnInit {
  lecturer = [];
  lecturerForm: FormGroup;
  course = [
    {
      "courseID": 0,
      "courseName": "IT",
      "startDate": "07/16/2019",
      "endDate": "07/16/2019"
    },
    {
      "courseID": 1,
      "courseName": "DB",
      "startDate": "07/16/2019",
      "endDate": "07/16/2019"
    },
    {
      "courseID": 2,
      "courseName": "SE",
      "startDate": "07/16/2019",
      "endDate": "07/16/2019"
    }
  ]
  index = 0;
  sub = false;

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.lecturerForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      designation: ['', Validators.required],
      selectedCourse: ['', Validators.required],
      address: ['', Validators.required],
      contactNo: ['', [Validators.required, Validators.minLength(10)]],
      dob: ['', Validators.required],
      doj: ['', Validators.required],
    });
  }

  get data() { return this.lecturerForm.controls; }





  addLecturer() {
    this.sub = true
    if (this.lecturerForm.invalid) {
      return;
    }
    //console.warn(this.studentForm.value);
    console.log(this.lecturerForm.value);
    var a = this.lecturerForm.value
    this.lecturer.push(a);
    alert('done');
    // this.student.push({
    //   SID: this.index++,
    //   Fname: this.firstName,
    //   Lname: this.lastName,
    //   Course: this.selectedCourse,
    //   Address: this.address,
    //   Contact: this.contactNo,
    //   DOB: this.dob,
    //   DOJ: this.doj
    // });
    console.log(this.lecturer);
  }

  clear() {
    this.sub = false;
    this.lecturerForm.reset();
  }
}
