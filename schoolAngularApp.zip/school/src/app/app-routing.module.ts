import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StudentComponent } from './student/student.component';
import { HomeComponent } from './home/home.component';
import { LecturerComponent } from './lecturer/lecturer.component';
import { CourseComponent } from './course/course.component';
import { StudentManagementComponent } from './student-management/student-management.component';
const routes: Routes = [
  {path: 'home' , component: HomeComponent},
  {path: 'student' , component: StudentComponent},
  {path: 'studentManagement' , component: StudentManagementComponent},
  {path: 'student/:id' , component: StudentComponent},
  {path: 'course' , component: CourseComponent},
  {path: 'lecturer' , component: LecturerComponent},
  { path: '',  redirectTo: '/home', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
